<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */
// ** MySQL settings ** //
/** The name of the database for WordPress */
define( 'DB_NAME', '' );
/** MySQL database username */
define( 'DB_USER', '' );
/** MySQL database password */
define( 'DB_PASSWORD', '' );
/** MySQL hostname */
define( 'DB_HOST', '' );
/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );
/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );
/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          '77<Zv(9Nl}.jJW F(Prh}6UIc^UXP?RSG~uH!^.DmA^S4|aGzf+%^Ag/*x,6!diM' );
define( 'SECURE_AUTH_KEY',   '? :mWxDQJM04fDm@S$BtU6kw$Mw^73~=(zlK1&?v/}X[9|=MvWJC!tg@4DAG{?h|' );
define( 'LOGGED_IN_KEY',     '689@Qu&t/:Z)?bBPNU$hFNd?R@hxoI,O7vk1hc}[b@wHu2U8m8KFK?<7-K(eL#VZ' );
define( 'NONCE_KEY',         'u3v8NM[x2|aKsO&PXZ1Uj2<i^rmH{~&=GmMu=4?n<?{evk&/Qbu^coCD;wF5A/tK' );
define( 'AUTH_SALT',         'gv5FpHAra;s([028rUk%:mqpPt|0SHQF_01V4[J=iW8f-_ZeHRnc8z n=Lql6dMx' );
define( 'SECURE_AUTH_SALT',  '&m-HtP,`@7,#9)N2 bNSs1vEPomp(nfjat}vWL[Qf~qZw$.EZP))+<P)?*W3/HSe' );
define( 'LOGGED_IN_SALT',    '83rcY?|YW@xA,.H;3;<un5,|JLRs Xc!k(8{fDsoDAVD@#Uv,kca}bG7[qp7Lz2/' );
define( 'NONCE_SALT',        '8G%qOJ?N)LqmE^4(g1O46,nP:tr>^E,bvJBn&/6{J5f?#(UENFd/`X}8]ebXIGiw' );
define( 'WP_CACHE_KEY_SALT', 'v&2Kk:C=)-Iv-cPb75XNKI#~PQl,I7nW4H1@T;/0s=sm|?|-K4+h/<0u=YYdbOVR' );
/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';
/* That's all, stop editing! Happy blogging. */
/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) )
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
