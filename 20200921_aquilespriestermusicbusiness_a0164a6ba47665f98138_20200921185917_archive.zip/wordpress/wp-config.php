<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wwjhon_wp' );

/** MySQL database username */
define( 'DB_USER', 'wwjhon_wp' );

/** MySQL database password */
define( 'DB_PASSWORD', 'XaSnparEIVKv' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          'h!]Cb,yEyew.b(`^d7Ux[xNEboSdmA pnK,m4-3!@~6+yJbBT>ir[091@B=R=EYR' );
define( 'SECURE_AUTH_KEY',   'nYoyic**kK6Zt{f1iZ^D1JbNIZ~y#]DV56, QB`k5j_*W#f7PY$-w&v7>VTFxCUV' );
define( 'LOGGED_IN_KEY',     'i_?N~W:;2gWngDWmz#-vtl9^wQUiv$@D;YgHR-k~zXs9~>=@6iIkr/H{*2Uki{O5' );
define( 'NONCE_KEY',         'A|Q.7|Jr`pA&05#)i@KNGLQGn{W]/:vL^ui&#3]U(+Sc(9/$qU062COt(-N<kCI0' );
define( 'AUTH_SALT',         '<CkPww#-CN[i5sR8jre*Q+|X>Y3QOi+A{7v{GZzwsv<&DCHxsg4?CE1D;j~:_{QH' );
define( 'SECURE_AUTH_SALT',  'lBca=i+jf!i38vmFtu3~+|paA4<*aRss&,`g7qUEFnFCk-+@Im-RHfJ Z,Jb5}?W' );
define( 'LOGGED_IN_SALT',    '(Wh#pa-XTxV90q%WJ!2t 1v[V0tn{<_UooI:C^T78;}~*f=<$vPx.;zA2bB]=[u#' );
define( 'NONCE_SALT',        '8IG~Ha`vPAfE0s>$V+k.z6PQL?BXULeW6,IW4>M&y/sV_4>?1izVh>-^{P{oVDsG' );
define( 'WP_CACHE_KEY_SALT', '^b?X&[rh.2_q9Jkd* J=D !bN}dXF:uw{|Tjern!Ui]$W3PK>~rS2w6q:(MMxA;.' );

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) )
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
